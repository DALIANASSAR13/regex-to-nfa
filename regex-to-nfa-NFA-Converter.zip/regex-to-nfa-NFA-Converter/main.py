from regex_parser import parse
from NFA_converter import postfix_to_nfa
from NFA_simulator import simulate_nfa, display_nfa

def main():
    print("--- Welcome to Regex-to-NFA Converter ---")
    user_regex = input("Enter your Regex (e.g., (a|b)*ab): ")
    
    try:
        # Step 1: Parsing (Dalia's Part)
        postfix = parse(user_regex)
        
        # Step 2: NFA Construction (Maryam's Part)
        final_nfa = postfix_to_nfa(postfix)
        
        # Step 3: Display and Simulation (Rania's Part)
        display_nfa(final_nfa)
        
        test_str = input("Enter a string to test against the NFA: ")
        if simulate_nfa(final_nfa, test_str):
            print("\n>>> Result: MATCHED! The string follows the pattern.")
        else:
            print("\n>>> Result: NO MATCH! The string doesn't follow the pattern.")
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()