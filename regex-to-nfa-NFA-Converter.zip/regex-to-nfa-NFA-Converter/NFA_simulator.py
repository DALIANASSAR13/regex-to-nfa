from NFA_converter import nfa, postfix_to_nfa

def get_epsilon_closure(states, transitions):
    """حساب الـ Epsilon Closure لجميع الحالات"""
    closure = set(states)
    stack = list(states)
    while stack:
        current = stack.pop()
        if current in transitions:
            for symbol, next_state in transitions[current]:
                if symbol == 'EPS' and next_state not in closure:
                    closure.add(next_state)
                    stack.append(next_state)
    return closure

def simulate_nfa(nfa_obj, input_string):
    """محاكاة حركة الكلمة داخل الـ NFA"""
    current_states = get_epsilon_closure([nfa_obj.start], nfa_obj.transitions)
    for char in input_string:
        next_states = set()
        for state in current_states:
            if state in nfa_obj.transitions:
                for symbol, next_state in nfa_obj.transitions[state]:
                    if symbol == char:
                        next_states.add(next_state)
        current_states = get_epsilon_closure(next_states, nfa_obj.transitions)
    return nfa_obj.accept in current_states

def display_nfa(nfa_obj):
    """عرض بيانات الـ NFA بشكل منظم للتقرير"""
    print("\n" + "="*40)
    print("      NFA STRUCTURE DETAILS")
    print("="*40)
    print(f"Start State  : {nfa_obj.start}")
    print(f"Accept State : {nfa_obj.accept}")
    print("-" * 40)
    print("Transitions:")
    for state, trans_list in nfa_obj.transitions.items():
        for symbol, next_state in trans_list:
            arrow = f"--({symbol})-->"
            print(f"  State {state:2} {arrow:12} State {next_state}")
    print("="*40 + "\n")

if __name__ == "__main__":

    display_nfa(nfa)
    print("NFA Simulator is Ready!")
    test_word = input("Enter a string to test: ")
    if simulate_nfa(nfa, test_word):
        print(f"Result: SUCCESS! The string '{test_word}' is accepted.")
    else:
        print(f"Result: FAILED! The string '{test_word}' is rejected.")