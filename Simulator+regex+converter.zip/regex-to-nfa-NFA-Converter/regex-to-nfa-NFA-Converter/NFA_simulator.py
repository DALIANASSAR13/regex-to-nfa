from NFA_converter import nfa, postfix_to_nfa

def get_epsilon_closure(states, transitions):
    closure = set(states)
    stack = list(states)
    
    while stack:
        current = stack.pop()
        if current in transitions:
            for symbol, next_state in transitions[current]:
                if symbol == 'EPS' and next_state not in closure:
                    closure.add(next_state)
                    stack.append(next_state)
    return closure

def simulate_nfa(nfa_obj, input_string):
    current_states = get_epsilon_closure([nfa_obj.start], nfa_obj.transitions)
    
    for char in input_string:
        next_states = set()
        for state in current_states:
            if state in nfa_obj.transitions:
                for symbol, next_state in nfa_obj.transitions[state]:
                    if symbol == char:
                        next_states.add(next_state)
        
        current_states = get_epsilon_closure(next_states, nfa_obj.transitions)
        
    return nfa_obj.accept in current_states

if __name__ == "__main__":
    print("-" * 30)
    print("NFA Simulator is Ready!")
    
    test_word = input("Enter a string to test: ")
    
    result = simulate_nfa(nfa, test_word)
    
    if result:
        print(f"Result: SUCCESS! The string '{test_word}' is accepted.")
    else:
        print(f"Result: FAILED! The string '{test_word}' is rejected.")